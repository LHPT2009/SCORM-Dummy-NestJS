if (!window.API) {
  window.API = {
    LMSInitialize: function () {
      // console.log("Mock LMSInitialize called.");
      return "true";
    },
    LMSFinish: function () {
      // console.log("Mock LMSFinish called.");
      return "true";
    },
    LMSGetValue: function (key) {
      // console.log(`Mock LMSGetValue called for ${key}`);
      return "";
    },
    LMSSetValue: function (key, value) {
      // console.log(`Mock LMSSetValue called for ${key} = ${value}`);
      return "true";
    },
    LMSCommit: function () {
      // console.log("Mock LMSCommit called.");
      return "true";
    },
    LMSGetLastError: function () {
      return "0";
    },
    LMSGetErrorString: function () {
      return "No error.";
    },
    LMSGetDiagnostic: function () {
      return "No diagnostic.";
    },
  };
}

// document.addEventListener("DOMContentLoaded", function () {
//   if (pipwerks.SCORM.init()) {
//     console.log("SCORM initialized successfully.");
//     pipwerks.SCORM.set("cmi.completion_status", "incomplete");
//   }
// });
